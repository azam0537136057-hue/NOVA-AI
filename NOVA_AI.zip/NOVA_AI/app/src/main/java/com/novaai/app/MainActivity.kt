package com.novaai.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val BACKEND_URL = "http://10.0.2.2:3000"
private const val PREFS = "nova_ai"
private const val KEY_USER = "user_name"
private const val KEY_MESSAGES = "messages"
private const val KEY_PREMIUM = "premium"
private const val KEY_USAGE = "usage"
private const val FREE_LIMIT = 10
private const val PREMIUM_LIMIT = 100

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp(this) }
    }
}

private fun loadMessages(context: Context): MutableList<String> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MESSAGES, null)
        ?: return mutableListOf("NOVA AI: مرحبًا! أنا NOVA AI 👋\nكيف أقدر أساعدك؟")
    val arr = JSONArray(raw)
    return MutableList(arr.length()) { i -> arr.optString(i) }
}

private fun saveMessages(context: Context, messages: List<String>) {
    val arr = JSONArray()
    messages.forEach { arr.put(it) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MESSAGES, arr.toString()).apply()
}

private suspend fun sendMessage(message: String): String = withContext(Dispatchers.IO) {
    val connection = (URL("$BACKEND_URL/api/chat").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 10000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
    }
    try {
        val body = JSONObject().put("message", message).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception(JSONObject(response).optString("error", "حدث خطأ في الخادم"))
        JSONObject(response).optString("reply", "لم يصل رد من الخادم")
    } finally { connection.disconnect() }
}

@Composable
fun NovaApp(context: Context) {
    val scope = rememberCoroutineScope()
    var userName by remember { mutableStateOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_USER, "") ?: "") }
    var showAccount by remember { mutableStateOf(userName.isBlank()) }
    var premium by remember { mutableStateOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PREMIUM, false)) }
    var usage by remember { mutableIntStateOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_USAGE, 0)) }
    var showPlans by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<String>().apply { addAll(loadMessages(context)) } }

    if (showAccount) {
        AccountScreen(
            initialName = userName,
            onSave = { name ->
                userName = name
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_USER, name).apply()
                showAccount = false
            }
        )
        return
    }

    if (showPlans) {
        PlansScreen(
            premium = premium,
            usage = usage,
            onBack = { showPlans = false },
            onDemoPremium = {
                premium = true
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PREMIUM, true).apply()
                showPlans = false
            }
        )
        return
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("NOVA AI") }, actions = { TextButton(onClick = { showPlans = true }) { Text(if (premium) "Premium" else "الترقية") }; TextButton(onClick = { showAccount = true }) { Text("حسابي") } }) },
            bottomBar = {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("اكتب رسالتك...") }, singleLine = true, enabled = !loading)
                    Spacer(Modifier.width(8.dp))
                    Button(enabled = text.isNotBlank() && !loading && usage < if (premium) PREMIUM_LIMIT else FREE_LIMIT, onClick = {
                        val userMessage = text.trim(); text = ""; messages.add("أنت: $userMessage"); saveMessages(context, messages); usage += 1; context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_USAGE, usage).apply(); loading = true
                        scope.launch {
                            try { messages.add("NOVA AI: ${sendMessage(userMessage)}") }
                            catch (_: Exception) { messages.add("NOVA AI: تعذر الاتصال بالخادم. تأكد أن الـBackend يعمل.") }
                            finally { saveMessages(context, messages); loading = false }
                        }
                    }) { Text(if (loading) "..." else "إرسال") }
                }
            }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("أهلًا ${userName.ifBlank { "بك" }} 👋", style = MaterialTheme.typography.headlineSmall) }
                item { Text(if (premium) "الحساب: Premium • الاستخدام: $usage / $PREMIUM_LIMIT" else "الحساب: مجاني • الاستخدام: $usage / $FREE_LIMIT") }
                item { LinearProgressIndicator(progress = { (usage.toFloat() / (if (premium) PREMIUM_LIMIT else FREE_LIMIT)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth()) }
                item { Text("المحادثات محفوظة على هذا الجهاز في هذه النسخة التجريبية.") }
                items(messages) { msg -> Card(Modifier.fillMaxWidth()) { Text(msg, Modifier.padding(14.dp)) } }
            }
        }
    }
}

@Composable
private fun PlansScreen(
    premium: Boolean,
    usage: Int,
    onBack: () -> Unit,
    onDemoPremium: () -> Unit
) {
    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text("خطط NOVA AI", style = MaterialTheme.typography.headlineMedium)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مجاني", style = MaterialTheme.typography.titleLarge)
                    Text("10 استخدامات AI في النسخة التجريبية")
                    Text(if (!premium) "الخطة الحالية" else "متاحة")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Premium", style = MaterialTheme.typography.titleLarge)
                    Text("حتى 100 استخدام في النسخة التجريبية + مزايا Premium")
                    if (premium) Text("الخطة مفعلة على هذا الجهاز")
                    else Button(onClick = onDemoPremium, modifier = Modifier.fillMaxWidth()) { Text("تفعيل Premium للتجربة") }
                }
            }
            Text("ملاحظة: زر Premium هنا تجريبي فقط، ولا يوجد دفع حقيقي بعد. سنضيف Google Play Billing بعد اختبار النظام.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AccountScreen(initialName: String, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(initialName) }
    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NOVA AI", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(12.dp))
            Text("إنشاء حساب محلي — النسخة التجريبية")
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسمك") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(onClick = { if (name.isNotBlank()) onSave(name.trim()) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("متابعة") }
        }
    }
}
